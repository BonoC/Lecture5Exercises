cat example_people_data.tsv | awk '{ 
FS="\t" ; 
if(NF == 7)
{print $0 ;} 
}' | wc -l 

#!/bin/bash

#How Many People Are There?

