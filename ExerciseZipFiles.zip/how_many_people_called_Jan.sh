#!/bin/bash

cat example_people_data.tsv | awk '{FS=t; if(NF == 7){print -bash;}}'|grep -wc Jan|wc -l

#Cat command displays the data, followed by awk which shows all lines that have 7 fields. Use grep function to collect only those that have the exact word Jan, then count the number of lines.
