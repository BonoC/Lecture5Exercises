#!/bin/bash

cat example_people_data.tsv | awk '{FS="\t"; 
if($6 <= 1989)
{ if(NF == 7)
{print $0 ;}}}'|wc -l

